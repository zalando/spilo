SFCGAL
======

SFCGAL is a C++ wrapper library around [CGAL](http://www.cgal.org) with the aim of supporting ISO 191007:2013 and OGC Simple Features for 3D operations.

Please refer to the <a href="http://oslandia.github.io/SFCGAL">project page</a> for an updated installation procedure.
